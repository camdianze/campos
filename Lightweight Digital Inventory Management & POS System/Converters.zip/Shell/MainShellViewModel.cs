﻿using PharmaPOS.Domain.Entities;
using PharmaPOS.Domain.Enums;
using Lightweight_Digital_Inventory_Management___POS_System.ViewModels.Base;

namespace Lightweight_Digital_Inventory_Management___POS_System.Shell;

/// <summary>로그인 후 메인 셸의 ViewModel. 로그인한 사용자 정보를 보관한다.</summary>
public class MainShellViewModel : ViewModelBase
{
    public User CurrentUser { get; }

    public string WelcomeMessage { get; }
    public string RoleDescription { get; }

    /// <summary>Admin Dashboard 버튼을 Administrator에게만 보여주기 위한 값.</summary>
    public bool IsAdministrator { get; }

    public RelayCommand ChangePasswordCommand { get; }
    public RelayCommand LogoutCommand { get; }

    public event Action? ChangePasswordRequested;
    public event Action? LogoutRequested;

    public MainShellViewModel(User loggedInUser)
    {
        CurrentUser = loggedInUser;
        WelcomeMessage = $"Welcome, {loggedInUser.Username}";

        RoleDescription = loggedInUser.Role switch
        {
            UserRole.Administrator => "[Placeholder] Administrator Dashboard",
            UserRole.FacilityStaff => "[Placeholder] Main Dashboard / POS Screen",
            _ => "[Placeholder] Unknown Role"
        };

        IsAdministrator = loggedInUser.Role == UserRole.Administrator;

        ChangePasswordCommand = new RelayCommand(_ => ChangePasswordRequested?.Invoke());
        LogoutCommand = new RelayCommand(_ => LogoutRequested?.Invoke());
    }
}