﻿using Microsoft.Extensions.DependencyInjection;
using System.Windows;
using System.Windows.Controls;
using PharmaPOS.Application.Authentication;
using PharmaPOS.Application.Inventory;
using PharmaPOS.Application.PasswordPolicy;
using PharmaPOS.Application.Repositories;
using PharmaPOS.Application.Security;
using PharmaPOS.DataAccess.Database;
using PharmaPOS.DataAccess.Repositories;
using Lightweight_Digital_Inventory_Management___POS_System.ViewModels;
using Lightweight_Digital_Inventory_Management___POS_System.Views;

namespace Lightweight_Digital_Inventory_Management___POS_System.Shell;

public partial class MainShellView : UserControl
{
    public MainShellView()
    {
        InitializeComponent();

        Loaded += (_, _) =>
        {
            if (DataContext is MainShellViewModel viewModel)
            {
                viewModel.LogoutRequested += OnLogoutRequested;
                viewModel.ChangePasswordRequested += () => OnChangePasswordRequested(viewModel);
            }
        };
    }

    private void OnLogoutRequested()
    {
        var parentWindow = System.Windows.Window.GetWindow(this);
        if (parentWindow is MainWindow mainWindow)
        {
            App.CurrentShellViewModel = null;
            mainWindow.Content = new LoginView();
        }
    }

    private void OnChangePasswordRequested(MainShellViewModel shellViewModel)
    {
        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;

        if (parentWindow is null)
        {
            return;
        }

        var changePasswordService = App.Services.GetRequiredService<IChangePasswordService>();
        var changePasswordViewModel = new ChangePasswordViewModel(changePasswordService, shellViewModel.CurrentUser);

        changePasswordViewModel.NavigateBackToLogin += () =>
        {
            App.CurrentShellViewModel = null;
            parentWindow.Content = new LoginView();
        };

        var changePasswordView = new ChangePasswordView
        {
            DataContext = changePasswordViewModel
        };

        parentWindow.Content = changePasswordView;
    }

    private void OnProductsClick(object sender, RoutedEventArgs e)
    {
        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = new ProductListView();
        }
    }

    private void OnStockInClick(object sender, RoutedEventArgs e)
    {
        if (DataContext is not MainShellViewModel shellViewModel)
        {
            return;
        }

        var productRepository = App.Services.GetRequiredService<IProductRepository>();
        var stockInService = App.Services.GetRequiredService<IStockInService>();

        var stockInViewModel = new StockInViewModel(
            productRepository, stockInService,
            shellViewModel.CurrentUser.FacilityId, shellViewModel.CurrentUser.UserId);

        var stockInView = new StockInView();
        stockInView.AttachViewModel(stockInViewModel);

        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = stockInView;
        }
    }

    private void OnInventoryClick(object sender, RoutedEventArgs e)
    {
        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = new InventoryStatusView();
        }
    }

    private void OnAdjustmentClick(object sender, RoutedEventArgs e)
    {
        if (DataContext is not MainShellViewModel shellViewModel)
        {
            return;
        }

        var productRepository = App.Services.GetRequiredService<IProductRepository>();
        var inventoryRepository = App.Services.GetRequiredService<IInventoryRepository>();
        var adjustmentService = App.Services.GetRequiredService<IAdjustmentService>();

        var adjustmentViewModel = new AdjustmentViewModel(
            productRepository, inventoryRepository, adjustmentService,
            shellViewModel.CurrentUser.FacilityId, shellViewModel.CurrentUser.UserId);

        var adjustmentView = new AdjustmentView();
        adjustmentView.AttachViewModel(adjustmentViewModel);

        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = adjustmentView;
        }
    }

    private void OnAlertsClick(object sender, RoutedEventArgs e)
    {
        if (DataContext is not MainShellViewModel shellViewModel)
        {
            return;
        }

        var alertService = App.Services.GetRequiredService<IAlertService>();
        var alertsViewModel = new AlertsViewModel(alertService, shellViewModel.CurrentUser.FacilityId);

        var alertsView = new AlertsView();
        alertsView.AttachViewModel(alertsViewModel);

        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = alertsView;
        }
    }

    private void OnPosSaleClick(object sender, RoutedEventArgs e)
    {
        if (DataContext is not MainShellViewModel shellViewModel)
        {
            return;
        }

        var productRepository = App.Services.GetRequiredService<IProductRepository>();
        var inventoryRepository = App.Services.GetRequiredService<IInventoryRepository>();
        var saleService = App.Services.GetRequiredService<ISaleService>();
        var receiptPrintingService = App.Services.GetRequiredService<IReceiptPrintingService>();

        var posSaleViewModel = new PosSaleViewModel(
            productRepository, inventoryRepository, saleService, receiptPrintingService,
            shellViewModel.CurrentUser.FacilityId, shellViewModel.CurrentUser.UserId,
            shellViewModel.CurrentUser.Role);

        var posSaleView = new PosSaleView();
        posSaleView.AttachViewModel(posSaleViewModel);

        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = posSaleView;
        }
    }

    private void OnAdminDashboardClick(object sender, RoutedEventArgs e)
    {
        if (DataContext is not MainShellViewModel shellViewModel)
        {
            return;
        }

        var dashboardService = App.Services.GetRequiredService<IAdminDashboardService>();
        var dashboardViewModel = new AdminDashboardViewModel(dashboardService, shellViewModel.CurrentUser.FacilityId);

        var dashboardView = new AdminDashboardView();
        dashboardView.AttachViewModel(dashboardViewModel);

        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = dashboardView;
        }
    }

    private void OnSalesHistoryClick(object sender, RoutedEventArgs e)
    {
        if (DataContext is not MainShellViewModel shellViewModel)
        {
            return;
        }

        var salesHistoryService = App.Services.GetRequiredService<ISalesHistoryService>();
        var receiptPrintingService = App.Services.GetRequiredService<IReceiptPrintingService>();

        var salesHistoryViewModel = new SalesHistoryViewModel(
            salesHistoryService, receiptPrintingService, shellViewModel.CurrentUser.FacilityId);

        var salesHistoryView = new SalesHistoryView();
        salesHistoryView.AttachViewModel(salesHistoryViewModel);

        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = salesHistoryView;
        }
    }

    private void OnRecoverySettingsClick(object sender, RoutedEventArgs e)
    {
        if (DataContext is not MainShellViewModel shellViewModel)
        {
            return;
        }

        var recoverySettingsService = App.Services.GetRequiredService<IRecoverySettingsService>();
        var recoverySettingsViewModel = new RecoverySettingsViewModel(
            recoverySettingsService, shellViewModel.CurrentUser.UserId, shellViewModel.CurrentUser.Username);

        var recoverySettingsView = new RecoverySettingsView();
        recoverySettingsView.AttachViewModel(recoverySettingsViewModel);

        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = recoverySettingsView;
        }
    }
}