﻿using System.IO;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using PharmaPOS.Application.Repositories;
using PharmaPOS.DataAccess.Database;
using Lightweight_Digital_Inventory_Management___POS_System.Composition;
using Lightweight_Digital_Inventory_Management___POS_System.Views;

namespace Lightweight_Digital_Inventory_Management___POS_System;

public partial class App : Application
{
    /// <summary>
    /// 앱 전체에서 사용하는 DI 컨테이너.
    /// 아직 DI로 전환되지 않은 View들이 과도기적으로 이 컨테이너에 접근할 수 있게
    /// 정적 속성으로 노출한다. (View 전환이 모두 끝나면 이 접근 방식 대신
    /// 생성자 주입만 남기는 걸 목표로 한다 — 지금은 마이그레이션 중간 단계이다.)
    /// </summary>
    public static IServiceProvider Services { get; private set; } = null!;

    /// <summary>
    /// 현재 로그인한 사용자의 셸 ViewModel.
    /// 로그인 성공 시 LoginView가 설정하고, 하위 화면(Stock-in 등)에서
    /// "메인 대시보드로 돌아가기"를 구현할 때 재사용한다.
    /// </summary>
    public static Shell.MainShellViewModel? CurrentShellViewModel { get; set; }

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var appDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "PharmaPOS");

        Directory.CreateDirectory(appDataFolder);

        var dbFilePath = Path.Combine(appDataFolder, "pharmapos.db");

        var services = new ServiceCollection();
        services.AddPharmaPosServices(dbFilePath);
        Services = services.BuildServiceProvider();

        var databaseInitializer = Services.GetRequiredService<DatabaseInitializer>();
        databaseInitializer.Initialize();

        var initialSetupRepository = Services.GetRequiredService<IInitialSetupRepository>();
        var isSetupComplete = await initialSetupRepository.IsSetupCompleteAsync();

        var mainWindow = new MainWindow();

        mainWindow.Content = isSetupComplete
            ? new LoginView()
            : new InitialSetupView();

        mainWindow.Show();
    }
}