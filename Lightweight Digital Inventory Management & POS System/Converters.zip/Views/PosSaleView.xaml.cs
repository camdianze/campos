﻿using System.Windows.Controls;
using System.Windows.Input;
using Lightweight_Digital_Inventory_Management___POS_System.ViewModels;

namespace Lightweight_Digital_Inventory_Management___POS_System.Views;

public partial class PosSaleView : UserControl
{
    public PosSaleView()
    {
        InitializeComponent();
    }

    public void AttachViewModel(PosSaleViewModel viewModel)
    {
        viewModel.SaleCompleted += OnSaleCompleted;
        viewModel.SaleCancelled += OnSaleCancelled;
        DataContext = viewModel;
    }

    private async void OnSearchBoxKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && DataContext is PosSaleViewModel viewModel)
        {
            await viewModel.ExecuteSearchAsync();
        }
    }

    private void OnSaleCompleted()
    {
        // 판매 완료 후에도 같은 화면(POS)에 그대로 머무른다 (다음 손님을 바로 응대).
        // ViewModel 내부에서 이미 폼이 초기화되었으므로 추가 처리는 필요 없다.
    }

    private void OnSaleCancelled()
    {
        var parentWindow = System.Windows.Window.GetWindow(this) as MainWindow;
        if (parentWindow is not null)
        {
            parentWindow.Content = new Shell.MainShellView
            {
                DataContext = App.CurrentShellViewModel
            };
        }
    }
}