﻿using Microsoft.Extensions.DependencyInjection;
using System.Windows.Controls;
using PharmaPOS.Domain.Entities;
using Lightweight_Digital_Inventory_Management___POS_System.Shell;
using Lightweight_Digital_Inventory_Management___POS_System.ViewModels;

namespace Lightweight_Digital_Inventory_Management___POS_System.Views;

public partial class LoginView : UserControl
{
    public LoginView()
    {
        InitializeComponent();

        var loginViewModel = App.Services.GetRequiredService<LoginViewModel>();
        loginViewModel.LoginSucceeded += OnLoginSucceeded;
        loginViewModel.ForgotUsernameRequested += OnForgotUsernameRequested;
        loginViewModel.ForgotPasswordRequested += OnForgotPasswordRequested;

        DataContext = loginViewModel;
    }

    private void OnLoginSucceeded(User loggedInUser)
    {
        var shellViewModel = new MainShellViewModel(loggedInUser);
        App.CurrentShellViewModel = shellViewModel;

        var shellView = new MainShellView
        {
            DataContext = shellViewModel
        };

        var parentWindow = System.Windows.Window.GetWindow(this);
        if (parentWindow is MainWindow mainWindow)
        {
            mainWindow.Content = shellView;
        }
    }

    private void OnForgotPasswordRequested()
    {
        var passwordRecoveryService = App.Services.GetRequiredService<PharmaPOS.Application.Authentication.IPasswordRecoveryService>();
        var recoveryViewModel = new PasswordRecoveryViewModel(passwordRecoveryService);

        var recoveryView = new PasswordRecoveryView();
        recoveryView.AttachViewModel(recoveryViewModel);

        var parentWindow = System.Windows.Window.GetWindow(this);
        if (parentWindow is MainWindow mainWindow)
        {
            mainWindow.Content = recoveryView;
        }
    }
    private void OnForgotUsernameRequested()
    {
        var passwordRecoveryService = App.Services.GetRequiredService<PharmaPOS.Application.Authentication.IPasswordRecoveryService>();
        var findUsernameViewModel = new FindUsernameViewModel(passwordRecoveryService);

        var findUsernameView = new FindUsernameView();
        findUsernameView.AttachViewModel(findUsernameViewModel);

        var parentWindow = System.Windows.Window.GetWindow(this);
        if (parentWindow is MainWindow mainWindow)
        {
            mainWindow.Content = findUsernameView;
        }
    }

}