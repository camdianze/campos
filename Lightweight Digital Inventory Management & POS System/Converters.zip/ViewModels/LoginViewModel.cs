﻿using PharmaPOS.Application.Authentication;
using PharmaPOS.Domain.Entities;
using Lightweight_Digital_Inventory_Management___POS_System.ViewModels.Base;

namespace Lightweight_Digital_Inventory_Management___POS_System.ViewModels;

/// <summary>
/// 로그인 화면(SCR-LOGIN-001)의 ViewModel.
/// </summary>
public class LoginViewModel : ViewModelBase
{
    private readonly IAuthenticationService _authenticationService;

    private string _username = string.Empty;
    private string _errorMessage = string.Empty;
    private bool _isBusy;

    public string Username
    {
        get => _username;
        set => SetProperty(ref _username, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                LoginCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public string ErrorMessage
    {
        get => _errorMessage;
        set => SetProperty(ref _errorMessage, value);
    }

    public RelayCommand LoginCommand { get; }
    public RelayCommand ForgotPasswordCommand { get; }
    public RelayCommand ForgotUsernameCommand { get; }
    /// <summary>
    /// 로그인 성공 시 발생. View(code-behind)가 이 이벤트를 구독해서 화면을 전환한다.
    /// </summary>
    public event Action<User>? LoginSucceeded;
    public event Action? ForgotPasswordRequested;
    public event Action? ForgotUsernameRequested;

    public LoginViewModel(IAuthenticationService authenticationService)
    {
        _authenticationService = authenticationService;
        LoginCommand = new RelayCommand(ExecuteLogin, CanExecuteLogin);
        ForgotPasswordCommand = new RelayCommand(_ => ForgotPasswordRequested?.Invoke());
        ForgotUsernameCommand = new RelayCommand(_ => ForgotUsernameRequested?.Invoke());
    }

    private bool CanExecuteLogin(object? parameter) => !IsBusy;

    private async void ExecuteLogin(object? parameter)
    {
        if (parameter is not System.Windows.Controls.PasswordBox passwordBox)
        {
            ErrorMessage = "Internal error: password box not found.";
            return;
        }

        var password = passwordBox.Password;

        if (string.IsNullOrWhiteSpace(Username))
        {
            ErrorMessage = "Please enter your username.";
            return;
        }

        if (string.IsNullOrWhiteSpace(password))
        {
            ErrorMessage = "Please enter your password.";
            return;
        }

        IsBusy = true;
        ErrorMessage = string.Empty;

        try
        {
            var result = await _authenticationService.LoginAsync(Username, password);

            if (result.IsSuccess)
            {
                LoginSucceeded?.Invoke(result.AuthenticatedUser!);
            }
            else
            {
                ErrorMessage = MapErrorToMessage(result.Error);
            }
        }
        finally
        {
            IsBusy = false;
        }
    }

    private static string MapErrorToMessage(AuthenticationError error) => error switch
    {
        AuthenticationError.UsernameEmpty => "Please enter your username.",
        AuthenticationError.PasswordEmpty => "Please enter your password.",
        AuthenticationError.InvalidCredentials => "Invalid username or password.",
        AuthenticationError.AccountInactive => "This account is inactive. Please contact the administrator.",
        AuthenticationError.FacilityInactive => "This facility is inactive. Please contact the administrator.",
        _ => "An unexpected error occurred."
    };
}