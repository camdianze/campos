﻿using System.Diagnostics;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using PharmaPOS.Application.Inventory;
using Lightweight_Digital_Inventory_Management___POS_System.ViewModels.Base;

namespace Lightweight_Digital_Inventory_Management___POS_System.ViewModels;

/// <summary>
/// 백업/내보내기 화면(SCR-BACKUP-018)의 ViewModel.
/// </summary>
public class BackupExportViewModel : ViewModelBase
{
    private readonly IBackupService _backupService;

    private string _backupLocation = string.Empty;
    private string? _selectedExportType;
    private bool _isCsvFormat = true;
    private string _backupFilePath = string.Empty;
    private string _message = string.Empty;

    public string BackupLocation
    {
        get => _backupLocation;
        set => SetProperty(ref _backupLocation, value);
    }

    /// <summary>"All" + 실제 테이블 이름들.</summary>
    public IReadOnlyList<string> AvailableExportTypes { get; }

    public string? SelectedExportType
    {
        get => _selectedExportType;
        set => SetProperty(ref _selectedExportType, value);
    }

    public bool IsCsvFormat
    {
        get => _isCsvFormat;
        set => SetProperty(ref _isCsvFormat, value);
    }

    public string BackupFilePath
    {
        get => _backupFilePath;
        set => SetProperty(ref _backupFilePath, value);
    }

    public string Message
    {
        get => _message;
        set => SetProperty(ref _message, value);
    }

    public RelayCommand SelectBackupLocationCommand { get; }
    public RelayCommand CreateDbBackupCommand { get; }
    public RelayCommand ExportDataCommand { get; }
    public RelayCommand SelectBackupFileCommand { get; }
    public RelayCommand RestoreDbCommand { get; }
    public RelayCommand BackCommand { get; }

    public event Action? NavigateBack;

    public BackupExportViewModel(IBackupService backupService)
    {
        _backupService = backupService;

        var exportTypes = new List<string> { "All" };
        exportTypes.AddRange(_backupService.GetExportableTableNames());
        AvailableExportTypes = exportTypes;

        SelectBackupLocationCommand = new RelayCommand(_ => ExecuteSelectBackupLocation());
        CreateDbBackupCommand = new RelayCommand(async _ => await ExecuteCreateDbBackupAsync());
        ExportDataCommand = new RelayCommand(async _ => await ExecuteExportDataAsync());
        SelectBackupFileCommand = new RelayCommand(_ => ExecuteSelectBackupFile());
        RestoreDbCommand = new RelayCommand(async _ => await ExecuteRestoreDbAsync());
        BackCommand = new RelayCommand(_ => NavigateBack?.Invoke());
    }

    private void ExecuteSelectBackupLocation()
    {
        var dialog = new OpenFolderDialog { Title = "Select Backup Location" };

        if (dialog.ShowDialog() == true)
        {
            BackupLocation = dialog.FolderName;
        }
    }

    private async Task ExecuteCreateDbBackupAsync()
    {
        Message = string.Empty;

        var result = await _backupService.CreateDatabaseBackupAsync(BackupLocation);

        Message = result.IsSuccess ? result.Message ?? "Backup created successfully." : result.Message!;
    }

    private async Task ExecuteExportDataAsync()
    {
        Message = string.Empty;

        var result = await _backupService.ExportDataAsync(BackupLocation, SelectedExportType, IsCsvFormat);

        Message = result.IsSuccess ? result.Message ?? "Export completed successfully." : result.Message!;
    }

    private void ExecuteSelectBackupFile()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Select Backup File",
            Filter = "SQLite Database (*.db)|*.db|All files (*.*)|*.*"
        };

        if (dialog.ShowDialog() == true)
        {
            BackupFilePath = dialog.FileName;
        }
    }

    private async Task ExecuteRestoreDbAsync()
    {
        Message = string.Empty;

        if (string.IsNullOrWhiteSpace(BackupFilePath))
        {
            Message = "Please select a backup file.";
            return;
        }

        // 복원 처리 원칙(Screen §5.1절): 위험도가 높은 작업이므로 반드시 확인 팝업을 표시한다.
        var confirm = MessageBox.Show(
            "Current data will be replaced. Continue?",
            "Confirm Restore", MessageBoxButton.YesNo, MessageBoxImage.Warning);

        if (confirm != MessageBoxResult.Yes)
        {
            Message = "Please confirm database restore.";
            return;
        }

        // 자동 백업 저장 위치: 사용자가 지정한 백업 위치가 있으면 그곳에,
        // 없으면 앱 데이터 폴더에 저장한다.
        var autoBackupFolder = string.IsNullOrWhiteSpace(BackupLocation)
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "PharmaPOS")
            : BackupLocation;

        var result = await _backupService.RestoreDatabaseAsync(BackupFilePath, autoBackupFolder);

        if (!result.IsSuccess)
        {
            Message = result.Message!;
            return;
        }

        // Screen §6절 "Restore 성공 → 앱 재시작 또는 로그인 화면".
        MessageBox.Show(
            "Database restored successfully. The application will now restart.",
            "Restart Required", MessageBoxButton.OK, MessageBoxImage.Information);

        RestartApplication();
    }

    private static void RestartApplication()
    {
        var exePath = Environment.ProcessPath;

        if (!string.IsNullOrEmpty(exePath))
        {
            Process.Start(exePath);
        }

        Application.Current.Shutdown();
    }
}