﻿using System.Collections.ObjectModel;
using System.Windows;
using PharmaPOS.Application.Inventory;
using PharmaPOS.Application.Repositories;
using Lightweight_Digital_Inventory_Management___POS_System.ViewModels.Base;

namespace Lightweight_Digital_Inventory_Management___POS_System.ViewModels;

/// <summary>
/// 재고 현황 화면(SCR-INV-008)의 ViewModel.
/// </summary>
public class InventoryStatusViewModel : ViewModelBase
{
    private readonly IInventoryRepository _inventoryRepository;

    private string _searchTerm = string.Empty;
    private ExpiryFilterOption _selectedExpiryFilter = ExpiryFilterOption.All;
    private bool _lowStockOnly;
    private InventorySortOption _selectedSortOption = InventorySortOption.ProductName;
    private InventoryStatusItem? _selectedItem;
    private string _message = string.Empty;

    public ObservableCollection<InventoryStatusItem> Items { get; } = new();

    public string SearchTerm
    {
        get => _searchTerm;
        set
        {
            if (SetProperty(ref _searchTerm, value))
            {
                _ = ReloadAsync();
            }
        }
    }

    public ExpiryFilterOption SelectedExpiryFilter
    {
        get => _selectedExpiryFilter;
        set
        {
            if (SetProperty(ref _selectedExpiryFilter, value))
            {
                _ = ReloadAsync();
            }
        }
    }

    public bool LowStockOnly
    {
        get => _lowStockOnly;
        set
        {
            if (SetProperty(ref _lowStockOnly, value))
            {
                _ = ReloadAsync();
            }
        }
    }

    public InventorySortOption SelectedSortOption
    {
        get => _selectedSortOption;
        set
        {
            if (SetProperty(ref _selectedSortOption, value))
            {
                _ = ReloadAsync();
            }
        }
    }

    public IReadOnlyList<ExpiryFilterOption> AvailableExpiryFilters { get; } =
        Enum.GetValues<ExpiryFilterOption>();

    public IReadOnlyList<InventorySortOption> AvailableSortOptions { get; } =
        Enum.GetValues<InventorySortOption>();

    public InventoryStatusItem? SelectedItem
    {
        get => _selectedItem;
        set => SetProperty(ref _selectedItem, value);
    }

    public string Message
    {
        get => _message;
        set => SetProperty(ref _message, value);
    }

    public RelayCommand ViewDetailCommand { get; }
    public RelayCommand StockInCommand { get; }
    public RelayCommand AdjustmentCommand { get; }

    public event Action? NavigateToStockIn;
    public event Action? NavigateToAdjustment;

    public InventoryStatusViewModel(IInventoryRepository inventoryRepository)
    {
        _inventoryRepository = inventoryRepository;

        ViewDetailCommand = new RelayCommand(_ => ExecuteViewDetail());
        StockInCommand = new RelayCommand(_ => NavigateToStockIn?.Invoke());
        AdjustmentCommand = new RelayCommand(_ => NavigateToAdjustment?.Invoke());

        _ = ReloadAsync();
    }

    public async Task ReloadAsync()
    {
        IReadOnlyList<InventoryStatusItem> results;

        try
        {
            results = await _inventoryRepository.GetInventoryStatusAsync(
                SearchTerm, SelectedExpiryFilter, LowStockOnly, SelectedSortOption);
        }
        catch (Exception)
        {
            Message = "Inventory data could not be loaded.";
            return;
        }

        Items.Clear();
        foreach (var item in results)
        {
            Items.Add(item);
        }

        Message = results.Count == 0 ? "No inventory records found." : string.Empty;
    }

    private void ExecuteViewDetail()
    {
        if (SelectedItem is null)
        {
            return;
        }

        var expiry = DateTimeOffset.FromUnixTimeMilliseconds(SelectedItem.ExpiryDate).ToLocalTime();
        var updated = DateTimeOffset.FromUnixTimeMilliseconds(SelectedItem.UpdatedAt).ToLocalTime();

        var detail = $"""
            Product: {SelectedItem.ProductName}
            Batch Number: {SelectedItem.BatchNumber}
            Current Quantity: {SelectedItem.CurrentQuantity}
            Selling Price: {SelectedItem.SellingPrice}
            Expiry Date: {expiry:yyyy-MM-dd}
            Last Updated: {updated:yyyy-MM-dd HH:mm}
            Low Stock: {(SelectedItem.IsLowStock ? "Yes" : "No")}
            """;

        MessageBox.Show(detail, "Inventory Detail");
    }
}